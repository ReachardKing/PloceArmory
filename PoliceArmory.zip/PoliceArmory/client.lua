--This is also for the police, this is an emergency load out, this should be accessed by a menu by the armory place in all the police stations 

_menuPool = NativeUI.CreatePool()
mainMenu = NativeUI.CreateMenu("Police Amory", "~b~Were Police do it Right")
_menuPool:Add(mainMenu)

-- Used in "FirstMenu"

bool = false

weapons = {
    "weapon_combatpistol",
    "weapon_flashlight",
    "weapon_stungun",
    "weapon_assultsmg",
    "weapon_pistol_mk2",
    "weapon_pistol",
    "weapn_pistol_mk2",
    "weapon_combatpistol",
    "weapon_appistol",
    "weapon_stungun",
    "weapon_pistol50",
    "weapon_snspistol",
    "weapon_snspistol_mk2",
    "weapon_heavypistol",
    "weapon_vintagepistol",
    "weapon_flaregun", 
    "weapon_marksmanpistol",
    "weapon_revolver", 
    "weapon_revolver_mk2",
    "weapon_doubleaction",
    "weapon_raypistol", 
    "weapon_ceramicpistol",
    "weapon_navyrevolver",
    "weapon_microsmg",
    "weapon_smg",
    "weapon_smg_mk2",
    "weapon_assaultsmg",
    "weapon_combatpdw",
    "weapon_machinepistol",
    "weapon_minismg",
    "weapon_raycarbine",
    "weapon_pumpshotgun",
    "weapon_pumpshotgun_mk2",
    "weapon_sawnoffshotgun",
    "weapon_assaultshotgun",
    "weapon_bullpupshotgun",
    "weapon_musket",
    "weapon_heavyshotgun",
    "weapon_dbshotgun",
    "weapon_autoshotgun",
    "weapon_assaultrifle",
    "weapon_assaultrifle_mk2",
    "weapon_carbinerifle",
    "weapon_carbinerifle_mk2",
    "weapon_advancedrifle",
    "weapon_specialcarbine",
    "weapon_specialcarbine_mk2",
    "weapon_bullpuprifle",
    "weapon_bullpuprifle_mk2",
    "weapon_compactrifle",
    "weapon_mg",
    "weapon_combatmg",
    "weapon_combatmg_mk2",
    "weapon_gusenberg",
    "weapon_sniperrifle",
    "weapon_heavysniper",
    "weapon_heavysniper_mk2",
    "weapon_marksmanrifle",
    "weapon_marksmanrifle_mk2",
    "weapon_rpg",
    "weapon_grenadelauncher",
    "weapon_grenadelauncher_smoke",
    "weapon_minigun",
    "weapon_firework",
    "weapon_railgun",
    "weapon_hominglauncher",
    "weapon_compactlauncher",
    "weapon_rayminigun"
}

function ThirdItem(menu)
   local gunsList = NativeUI.CreateListItem("Get Guns →→→", weapons, 1)
   menu:AddItem(gunsList)
   menu.OnListSelect = function(sender, item, index)  
       if item == gunsList then
           local selectedGun = item:IndexToItem(index)
           giveWeapon(selectedGun)
           notify("spawned in a ~b~".. selectedGun)
       end
   end
end
function SexthItem(menu) 
    local submenu = _menuPool:AddSubMenu(menu, "~g~About →→→", "About PoliceArmory menu")
    local About = NativeUI.CreateItem("About", "This is a brand new menu made by ~b~Mackenzie_Rich") 
    submenu.OnItemSelect = function (sender, item, checked_)
       -- check if what changed is from this menu
       if item == About then
            GetSelected()
            notify("About")
        end
    end
    local Version = NativeUI.CreateItem("PoliceArmory Version", "~r~1.0.0")
    submenu.OnItemSelect = function(sender, item, checked_)
        if item == click then
            GetVerion()
            notify("~g~No New Update")
        end
    end
    submenu:AddItem(About)
    submenu:AddItem(Version)
end



ThirdItem(mainMenu)
SexthItem(mainMenu)
_menuPool:RefreshIndex()

-- DisplayHelpText("~b~Press ~INPUT_CONTEXT~ to open  ~w~ The Menu")

---Key to Open Menu
RegisterCommand('PoliceArmory', function() --edit this line to to change the command
    mainMenu:Visible(not mainMenu:Visible())
end, false)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(2)
        _menuPool:ProcessMenus()
		if IsControlJustPressed(1, 344) and IsControlJustPressed(1, 344) then
            ExecuteCommand('PoliceArmory')
            DisplayHelpText("~b~Press ~INPUT_SWITCH_VISOR~ to open  ~w~ The Menu")
		end
	end
end)   

_menuPool:MouseControlsEnabled (false);
_menuPool:MouseEdgeEnabled (false);
_menuPool:ControlDisablingEnabled(false);

--Shows a notification on the player's screen 
function ShowNotification( text )
   SetNotificationTextEntry( "STRING" )
   AddTextComponentString( text )
   DrawNotification( false, false )
end

function DisplayHelpText(str)
	SetTextComponentFormat("STRING")
	AddTextComponentString(str)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

function drawTxt(x,y ,width,height,scale, text, r,g,b,a, outline)
    SetTextFont(0)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    if(outline)then
	    SetTextOutline()
	end
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end

--[[ COPY BELOW ]]

function giveWeapon(hash)
   GiveWeaponToPed(GetPlayerPed(-1), GetHashKey(hash), 999, false, false)
end
