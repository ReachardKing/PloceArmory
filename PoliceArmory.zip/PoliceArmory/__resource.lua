resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

--version "1.0.0"

client_script {
	--"dependency/*" untick this if you do not have NativeUI folder
	'@NativeUI/NativeUI.lua',
	'client.lua'
	-- Add a congig if you know what your doing
}	
server_script 'server.lua'
