RegisterCommand('clearchat', function(source, args)
    TriggerEvent('chat:clear')
end, false)